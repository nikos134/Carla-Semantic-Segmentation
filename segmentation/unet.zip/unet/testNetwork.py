from keras.models import load_model
import cv2
import numpy as np
import os
import random
import skimage.io
import matplotlib.pyplot as plt
from model.unet import unet
from keras import backend as K
import tensorflow as tf
from keras.backend.tensorflow_backend import set_session
tf_config = tf.ConfigProto()
tf_config.gpu_options.per_process_gpu_memory_fraction = 0.8
set_session(tf.Session(config=tf_config))

random.seed(0)
class_colors = [(0,0,0),  	( 70, 70, 70), (190, 153, 153), 	(250, 170, 160), (220, 20, 60),(153, 153, 153),(157, 234, 50),(128, 64, 128),(244, 35, 232),(107, 142, 35),( 0, 0, 142),(102, 102, 156),(220, 220, 0)]

def dice_coef(y_true, y_pred):
    return (2. * K.sum(y_true * y_pred) + 1.) / (K.sum(y_true) + K.sum(y_pred) + 1.)


def compileImage(b_size, images):

    image_seg_batch = np.zeros((10, 256, 512, 3))
    image_seg_batch_final = np.zeros((10, 512, 512, 3))
    for i in range(b_size):
        predicted_image = images[i].reshape((256,512,13))

        # print(np.amax(predicted_image[:,:,1]))

        for j in range(13):

            image_seg_batch[i, :, :, 0] += ((predicted_image[:, :, j] > 0.5) * (class_colors[j][0])).astype('uint8')
            image_seg_batch[i, :, :, 1] += ((predicted_image[:, :, j]> 0.5) * (class_colors[j][1])).astype('uint8')
            image_seg_batch[i, :, :, 2] += ((predicted_image[:, :, j]> 0.5) * (class_colors[j][2])).astype('uint8')
        image_seg_batch_final[i] = cv2.resize(image_seg_batch[i], (512, 512))
    # labels = ["Unlabeled", "Building", "Fence", "Other", "Pedestrian", "Pole", "Road Line", "Road", "Sidewalk",
    #           "Vegetation", "Car", "Wall", "Traffic Sign"]
    # for row in range(5):
    #     for col in range(4):
    #         if 4 * row + col >= 13:
    #             continue
    #         ax = plt.subplot(5, 4, 4 * row + col + 1)
    #         ax.title.set_text(labels[4 * row + col])
    #         plt.imshow(predicted_image[:, :, 4 * row + col])
    # plt.imshow(image_seg_batch[0])
    # plt.show()
    return image_seg_batch_final


def startVideo():
    return cv2.VideoWriter('test1.avi', 1482049860, 10, frameSize=(1536, 512))


def createVideo(out, images):
    for i in range(len(images)):
        out.write(np.uint8(images[i]))


def endVideo(out):
    out.release()



RGB_TRAIN_DIR = "/media/nikos134/DATADRIVE1/onedrive/21_06/trainData/RGB"
SEG_TRAIN_DIR = "/media/nikos134/DATADRIVE1/onedrive/21_06/trainData/SEG"

# RGB_VAL_DIR = "/media/nikos134/DATADRIVE1/onedrive/21_06/valData/RGB"
# SEG_VAL_DIR = "/media/nikos134/DATADRIVE1/onedrive/21_06/valData/SEG"
ROOT_DIR = os.path.abspath("/media/nikos134/DATADRIVE1/onedrive/CNN/deepLab")

RGB_VAL_DIR = "/media/nikos134/DATADRIVE1/CarlaData/20_06_2/_out_0"
SEG_VAL_DIR = "/media/nikos134/DATADRIVE1/CarlaData/20_06_2/_out_2"


batch = 10

model_path = os.path.join(ROOT_DIR,'ver3.h5')
model = load_model(model_path,custom_objects={'dice_coef': dice_coef})

out = startVideo()
for j in range(100):
    print("Batch: ", j)
    images = os.listdir(RGB_VAL_DIR)
    image_batch = np.zeros((batch, 256, 512, 3))
    image_batch_for_video = np.zeros((batch, 512, 512, 3))
    image_seg_batch_for_video = np.zeros((batch, 512, 512, 3))

    for i in range(batch):
        image = skimage.io.imread(os.path.join(RGB_VAL_DIR, images[j*10 + i]))
        image_seg = skimage.io.imread(os.path.join(SEG_VAL_DIR, images[j*10 + i]))

        if image.shape[-1] == 4:
            image = image[..., :3]
        if image_seg.shape[-1] == 4:
            image_seg = image_seg[..., :3]

        image = cv2.resize(image, (512, 512))
        image_seg = cv2.resize(image_seg, (512, 512))
        image_batch_for_video[i] = image
        image_seg_batch_for_video[i] = image_seg
        image = cv2.resize(image, (512, 256))
        image_batch[i] = image

    features = model.predict(image_batch)

    images = compileImage(batch, features)

    final_video = np.zeros((batch, 512, 1536, 3))

    final_video[:, :, :512, :] = image_batch_for_video

    final_video[:, :, 512:1024, :] = image_seg_batch_for_video
    final_video[:, :, 1024:, :] = images

    createVideo(out, final_video)

endVideo(out)
