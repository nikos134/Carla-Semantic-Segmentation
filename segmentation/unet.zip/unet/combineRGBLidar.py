import os
import cv2




dir = "/media/nikos134/DATADRIVE1/CarlaData/25_07/CarlaDataset/"
dirTo = "/media/nikos134/DATADRIVE1/CarlaData/25_07/CarlaDataset/"



images = os.listdir(dir)